# FindMyPhone — Version 1

A privacy-preserving Android starter app for locating a phone owned by the signed-in user.

## What it does
- Requests Android location permission.
- Runs a foreground location service.
- Uploads the device's latest location to Firebase Firestore.
- Uses the user's Firebase UID as the device record key.
- Includes a basic lost-mode UI.
- Includes Firebase Cloud Messaging foundation for future authenticated commands.

## Important
The phone number is an account/device identifier only. It does NOT magically locate arbitrary phones by number.

## Firebase setup
1. Create a Firebase project.
2. Add an Android app using package:
   `com.example.findmyphone`
3. Download `google-services.json`.
4. Put it at:
   `app/google-services.json`
5. Enable Firebase Authentication and Firestore.
6. Choose an authentication method such as email/password or phone authentication.
7. Add Firestore security rules so users can only read/write their own `/devices/{uid}` document.

Example starting rule:

rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /devices/{uid} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}

## Build
Open this folder in Android Studio and let Gradle sync.

## Next version
Add real sign-in, a map screen, device pairing, authenticated remote ring/lock commands, and a secure web dashboard.
