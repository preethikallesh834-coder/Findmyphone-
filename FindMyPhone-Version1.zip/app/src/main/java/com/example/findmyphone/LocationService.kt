package com.example.findmyphone

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class LocationService : Service() {
    private lateinit var client: FusedLocationProviderClient

    override fun onCreate() {
        super.onCreate()
        client = LocationServices.getFusedLocationProviderClient(this)
        createChannel()
        startForeground(1001, notification())

        val request = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY, 30_000L
        ).setMinUpdateIntervalMillis(15_000L).build()

        try {
            client.requestLocationUpdates(request, callback, mainExecutor)
        } catch (_: SecurityException) {
            stopSelf()
        }
    }

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val user = FirebaseAuth.getInstance().currentUser ?: return
            val loc = result.lastLocation ?: return

            FirebaseFirestore.getInstance()
                .collection("devices")
                .document(user.uid)
                .set(
                    mapOf(
                        "latitude" to loc.latitude,
                        "longitude" to loc.longitude,
                        "accuracyMeters" to loc.accuracy,
                        "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                    ),
                    com.google.firebase.firestore.SetOptions.merge()
                )
        }
    }

    override fun onDestroy() {
        client.removeLocationUpdates(callback)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun notification(): Notification =
        NotificationCompat.Builder(this, "location")
            .setContentTitle("FindMyPhone")
            .setContentText("Location sharing is active")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .build()

    private fun createChannel() {
        val channel = NotificationChannel(
            "location", "Location sharing", NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    companion object {
        fun start(context: Context) {
            androidx.core.content.ContextCompat.startForegroundService(
                context, Intent(context, LocationService::class.java)
            )
        }
    }
}
