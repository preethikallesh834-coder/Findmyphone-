package com.example.findmyphone

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ))
        }

        setContent {
            MaterialTheme {
                FindMyPhoneScreen(
                    onStartTracking = {
                        LocationService.start(this)
                    }
                )
            }
        }
    }
}

@Composable
fun FindMyPhoneScreen(onStartTracking: () -> Unit) {
    var phoneNumber by remember { mutableStateOf("") }
    var lostMode by remember { mutableStateOf(false) }

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("FindMyPhone", style = MaterialTheme.typography.headlineMedium)
            Text("Register your own device and keep its location available for recovery.")

            OutlinedTextField(
                value = phoneNumber,
                onValueChange = { phoneNumber = it },
                label = { Text("Your phone number") },
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = onStartTracking,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Start location sharing")
            }

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Lost mode")
                Switch(
                    checked = lostMode,
                    onCheckedChange = { lostMode = it }
                )
            }

            Text(
                if (lostMode)
                    "Lost mode is enabled. Your registered device can continue reporting its location."
                else
                    "Lost mode is off."
            )
        }
    }
}
