package com.example.findmyphone

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class FindMyFirebaseMessagingService : FirebaseMessagingService() {
    override fun onMessageReceived(message: RemoteMessage) {
        // Version 1 foundation for commands such as RING or LOST_MODE.
        // Implement authenticated command handling in Version 2.
    }
}
